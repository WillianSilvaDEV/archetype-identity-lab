import { createFileRoute } from "@tanstack/react-router";
import { Footer } from "@/components/landing/Footer";
import { Section, Eyebrow } from "@/components/landing/Section";
import { Reveal } from "@/components/landing/Reveal";
import { company } from "@/config/company";

export const Route = createFileRoute("/termos-de-uso")({
  head: () => ({
    meta: [
      { title: "Termos de Uso | Cristiano Oliveira" },
      {
        name: "description",
        content:
          "Condições para uso do site, cadastro, recebimento do e-book gratuito e comunicações.",
      },
      { name: "robots", content: "index,follow" },
      { property: "og:title", content: "Termos de Uso | Cristiano Oliveira" },
      {
        property: "og:description",
        content: "Condições de uso e de cadastro.",
      },
      {
        property: "og:url",
        content: `${company.siteUrl}/termos-de-uso`,
      },
    ],
  }),
  component: TermosPage,
});

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Reveal className="border-t border-brand-line pt-8 first:border-0 first:pt-0">
      <h2 className="display-font text-xl text-white md:text-2xl">{title}</h2>
      <div className="mt-3 space-y-3 text-sm leading-relaxed text-brand-muted md:text-base">
        {children}
      </div>
    </Reveal>
  );
}

function TermosPage() {
  return (
    <main className="flex min-h-screen flex-col bg-brand text-white">
      <Section>
        <Reveal>
          <Eyebrow>Informações legais</Eyebrow>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="display-font text-3xl leading-[1.1] md:text-5xl">
            Termos de{" "}
            <span style={{ color: "var(--brand-neon)" }}>Uso</span>
          </h1>
        </Reveal>
        <Reveal delay={140}>
          <p className="mt-4 text-sm text-brand-muted">
            Versão {company.versaoLegal} — Última atualização em{" "}
            {company.dataAtualizacaoLegal}
          </p>
        </Reveal>

        <div className="mt-12 space-y-10">
          <Block title="1. Objeto">
            <p>
              Estes Termos regem o uso do site e a oferta de material gratuito
              (e-book sobre arquétipos de marca) por{" "}
              <span className="text-white">{company.razaoSocial}</span>, CNPJ{" "}
              {company.cnpj}.
            </p>
          </Block>

          <Block title="2. Cadastro">
            <p>
              Ao se cadastrar, você declara que os dados fornecidos são
              verdadeiros, completos e atualizados, e que possui pelo menos 18
              anos de idade ou está devidamente representado por responsável
              legal.
            </p>
          </Block>

          <Block title="3. Gratuidade e contrapartida">
            <p>
              O e-book é disponibilizado gratuitamente. Em contrapartida, você
              aceita receber comunicações de Cristiano Oliveira pelos canais
              informados no cadastro (WhatsApp e e-mail), podendo descadastrar
              a qualquer momento.
            </p>
          </Block>

          <Block title="4. Propriedade intelectual">
            <p>
              Todo o conteúdo deste site e do e-book — incluindo textos,
              imagens, marca, identidade visual e materiais derivados — é de
              titularidade exclusiva do autor. É vedada qualquer redistribuição
              comercial, reprodução não autorizada ou criação de obras
              derivadas sem consentimento prévio e por escrito.
            </p>
          </Block>

          <Block title="5. Limitação de responsabilidade">
            <p>
              O conteúdo oferecido tem caráter informativo e educacional. Não
              substitui consultoria personalizada, análise estratégica
              profissional ou aconselhamento jurídico, contábil ou de
              marketing. Decisões tomadas com base no material são de
              responsabilidade do leitor.
            </p>
          </Block>

          <Block title="6. Comunicações">
            <p>
              As comunicações podem incluir entregas de conteúdo, convites para
              eventos, novidades sobre serviços e ofertas. A frequência
              prevista é de baixa a moderada. Você pode descadastrar a qualquer
              momento solicitando ao nosso DPO pelo e-mail{" "}
              <span className="text-white">{company.emailDpo}</span> ou
              utilizando o link de descadastro presente em nossos e-mails.
            </p>
          </Block>

          <Block title="7. Alterações dos termos">
            <p>
              Estes Termos podem ser atualizados. A versão e a data da última
              atualização constam no topo desta página. O uso contínuo do site
              após a publicação implica concordância com a versão vigente.
            </p>
          </Block>

          <Block title="8. Lei aplicável e foro">
            <p>
              Estes Termos são regidos pelas leis da República Federativa do
              Brasil. Fica eleito o foro da comarca do estabelecimento da
              empresa para dirimir quaisquer controvérsias.
            </p>
          </Block>
        </div>
      </Section>
      <Footer />
    </main>
  );
}
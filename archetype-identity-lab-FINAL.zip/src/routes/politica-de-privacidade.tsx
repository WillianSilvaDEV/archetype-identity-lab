import { createFileRoute } from "@tanstack/react-router";
import { Footer } from "@/components/landing/Footer";
import { Section, Eyebrow } from "@/components/landing/Section";
import { Reveal } from "@/components/landing/Reveal";
import { company } from "@/config/company";

export const Route = createFileRoute("/politica-de-privacidade")({
  head: () => ({
    meta: [
      { title: "Política de Privacidade | Cristiano Oliveira" },
      {
        name: "description",
        content:
          "Como tratamos seus dados pessoais em conformidade com a LGPD: coleta, uso, compartilhamento, direitos e segurança.",
      },
      { name: "robots", content: "index,follow" },
      { property: "og:title", content: "Política de Privacidade | Cristiano Oliveira" },
      {
        property: "og:description",
        content: "Tratamento de dados pessoais conforme a LGPD.",
      },
      {
        property: "og:url",
        content: `${company.siteUrl}/politica-de-privacidade`,
      },
    ],
  }),
  component: PoliticaPage,
});

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Reveal className="border-t border-brand-line pt-8 first:border-0 first:pt-0">
      <h2 className="display-font text-xl text-white md:text-2xl">{title}</h2>
      <div className="mt-3 space-y-3 text-sm leading-relaxed text-brand-muted md:text-base">
        {children}
      </div>
    </Reveal>
  );
}

function PoliticaPage() {
  return (
    <main className="flex min-h-screen flex-col bg-brand text-white">
      <Section>
        <Reveal>
          <Eyebrow>Informações legais</Eyebrow>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="display-font text-3xl leading-[1.1] md:text-5xl">
            Política de{" "}
            <span style={{ color: "var(--brand-neon)" }}>Privacidade</span>
          </h1>
        </Reveal>
        <Reveal delay={140}>
          <p className="mt-4 text-sm text-brand-muted">
            Versão {company.versaoLegal} — Última atualização em{" "}
            {company.dataAtualizacaoLegal}
          </p>
        </Reveal>

        <div className="mt-12 space-y-10">
          <Block title="1. Quem somos">
            <p>
              Esta plataforma é mantida por{" "}
              <span className="text-white">{company.razaoSocial}</span>, inscrita
              no CNPJ sob o nº {company.cnpj}, com sede em {company.endereco}.
              Para contato direto, utilize o e-mail{" "}
              <span className="text-white">{company.emailContato}</span>.
            </p>
          </Block>

          <Block title="2. Quais dados coletamos">
            <p>
              Coletamos apenas o necessário para entregar o material e manter o
              relacionamento que você autoriza: nome, e-mail, número de
              WhatsApp, tamanho da empresa (faixa de colaboradores), origem do
              cadastro, user-agent do navegador e data/hora do envio.
            </p>
          </Block>

          <Block title="3. Para que usamos seus dados">
            <p>
              (a) Entregar o e-book pelo WhatsApp e e-mail; (b) enviar
              comunicações sobre serviços de branding, novos materiais e
              conteúdos relacionados; (c) gerar métricas internas agregadas para
              melhorar nossas ofertas.
            </p>
          </Block>

          <Block title="4. Base legal (LGPD)">
            <p>
              Tratamos seus dados com base no{" "}
              <span className="text-white">consentimento</span> (art. 7º, I da
              LGPD) para comunicações de marketing, e na{" "}
              <span className="text-white">execução de contrato</span> (art. 7º,
              V) para a entrega do material gratuito solicitado.
            </p>
          </Block>

          <Block title="5. Compartilhamento com terceiros">
            <p>
              Compartilhamos dados estritamente com operadores que viabilizam o
              serviço: Supabase (banco de dados), Meta / WhatsApp Business
              Platform (envio de mensagens), provedor de e-mail marketing
              (quando aplicável) e Cloudflare (CDN e infraestrutura).
            </p>
            <p className="text-white">Não vendemos, alugamos ou cedemos seus dados.</p>
          </Block>

          <Block title="6. Por quanto tempo guardamos">
            <p>
              Mantemos seus dados por até 24 meses após o último contato, ou
              enquanto durar o relacionamento, ou até que você solicite a
              exclusão — o que ocorrer primeiro. Registros legais podem ser
              mantidos por períodos maiores quando exigidos por lei.
            </p>
          </Block>

          <Block title="7. Seus direitos como titular (art. 18 LGPD)">
            <p>
              Você pode, a qualquer momento: confirmar a existência de
              tratamento; acessar seus dados; corrigir dados incompletos,
              inexatos ou desatualizados; solicitar anonimização, bloqueio ou
              eliminação de dados desnecessários; pedir portabilidade; revogar
              o consentimento; e obter informações sobre compartilhamento com
              terceiros.
            </p>
          </Block>

          <Block title="8. Como exercer seus direitos">
            <p>
              Envie sua solicitação ao nosso Encarregado de Dados (DPO) pelo
              e-mail{" "}
              <span className="text-white">{company.emailDpo}</span>. Respondemos
              em até 15 dias.
            </p>
          </Block>

          <Block title="9. Cookies">
            <p>
              Utilizamos cookies essenciais para o funcionamento do site e
              cookies de analytics para entender o desempenho das páginas. Você
              pode bloqueá-los nas configurações do seu navegador — algumas
              funções podem ser afetadas.
            </p>
          </Block>

          <Block title="10. Segurança">
            <p>
              Adotamos medidas técnicas e organizacionais razoáveis: tráfego
              criptografado em TLS, banco de dados com Row-Level Security (RLS)
              e acesso restrito a operadores autorizados.
            </p>
          </Block>

          <Block title="11. Alterações desta política">
            <p>
              Esta política pode ser atualizada. A versão e a data da última
              atualização constam no topo desta página. Mudanças relevantes
              serão comunicadas pelos canais de contato fornecidos.
            </p>
          </Block>

          <Block title="12. Lei aplicável e foro">
            <p>
              Esta política é regida pelas leis da República Federativa do
              Brasil. Fica eleito o foro da comarca do estabelecimento da
              empresa para dirimir quaisquer controvérsias.
            </p>
          </Block>
        </div>
      </Section>
      <Footer />
    </main>
  );
}
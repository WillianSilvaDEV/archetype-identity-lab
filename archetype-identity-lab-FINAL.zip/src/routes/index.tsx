import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Sparkles,
  Target,
  TrendingDown,
  Eye,
  MessageSquareOff,
  Fingerprint,
  Brain,
  Heart,
  Crown,
  Search,
  Award,
  Globe2,
  CheckCircle2,
  Star,
} from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { LeadForm } from "@/components/landing/LeadForm";
import { EbookMockup } from "@/components/landing/EbookMockup";
import { Reveal } from "@/components/landing/Reveal";
import { Section, Eyebrow } from "@/components/landing/Section";
import { Footer } from "@/components/landing/Footer";
import { StickyCTA } from "@/components/landing/StickyCTA";
import cristianoPhoto from "@/assets/cristiano.webp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title:
          "Descubra o Seu Arquétipo de Marca | Cristiano Oliveira",
      },
      {
        name: "description",
        content:
          "E-book gratuito sobre branding estratégico e arquétipos de marca. Descubra qual identidade sua marca transmite ao mercado.",
      },
      {
        property: "og:title",
        content: "Descubra o Seu Arquétipo de Marca",
      },
      {
        property: "og:description",
        content:
          "Branding forte não nasce do visual. Nasce da percepção. Baixe o e-book gratuito de Cristiano Oliveira.",
      },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <main className="relative min-h-screen overflow-x-hidden bg-brand text-white">
      <Toaster theme="dark" richColors position="top-center" />
      <Hero />
      <ProblemSection />
      <BenefitsSection />
      <MechanismSection />
      <AuthorSection />
      <PatternBreakSection />
      <FinalCTASection />
      <Footer />
      <StickyCTA />
    </main>
  );
}

/* ---------------- HERO ---------------- */
function Hero() {
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    const onScroll = () => setOffset(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section className="relative isolate flex min-h-[100svh] flex-col overflow-hidden px-5 pb-6 pt-6 md:px-8 md:pb-28 md:pt-28 lg:min-h-screen lg:block lg:pt-32">
      {/* Cinematic background layers */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-30"
        style={{ backgroundColor: "#050505" }}
      />
      {/* Soft right-side key light */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-20"
        style={{
          background:
            "radial-gradient(45% 70% at 78% 38%, rgba(217,255,0,0.10), transparent 65%), radial-gradient(35% 55% at 85% 75%, rgba(217,255,0,0.05), transparent 70%)",
        }}
      />
      {/* Distant ambient fill */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-20"
        style={{
          background:
            "radial-gradient(60% 50% at 20% 20%, rgba(255,255,255,0.04), transparent 70%)",
        }}
      />
      {/* Vignette */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(120% 100% at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%)",
        }}
      />
      {/* Subtle grain */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 bg-grain opacity-[0.4] mix-blend-screen"
      />
      {/* Top hairline */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-px"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(255,255,255,0.12), transparent)",
        }}
      />

      <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col lg:grid lg:flex-none lg:grid-cols-[1.05fr_1fr] lg:items-center lg:gap-10 xl:gap-16">
        {/* Left: copy + CTA — mobile: bottom overlay; desktop: left column */}
        <div className="relative z-10 mt-auto lg:order-1 lg:mt-0">
          <Reveal>
            <div className="mb-3 inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.24em] text-white/70 backdrop-blur-md lg:mb-7">
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{
                  background: "var(--brand-neon)",
                  boxShadow: "0 0 10px rgba(217,255,0,0.8)",
                }}
              />
              E-book gratuito
              <span className="text-white/25">/</span>
              <span className="text-white/55">Branding estratégico</span>
            </div>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="display-font text-[1.85rem] leading-[1.04] tracking-[-0.035em] text-white sm:text-[2.4rem] lg:text-[3.6rem]">
              Descubra o{" "}
              <span
                className="relative inline-block"
                style={{ color: "var(--brand-neon)" }}
              >
                arquétipo
                <span
                  aria-hidden
                  className="absolute inset-x-0 -bottom-1 h-px"
                  style={{
                    background:
                      "linear-gradient(90deg, transparent, rgba(217,255,0,0.55), transparent)",
                  }}
                />
              </span>{" "}
              que pode transformar sua marca em uma{" "}
              <span className="text-white/95">autoridade</span> impossível de
              ignorar.
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-3 hidden max-w-[560px] text-[15px] leading-[1.7] text-white/65 md:block md:text-[17px] lg:mt-6">
              A maioria das marcas tenta crescer com mais conteúdo, tráfego e
              anúncios. Mas o verdadeiro posicionamento começa na forma como o
              mercado{" "}
              <span className="text-white">percebe você</span>.
            </p>
          </Reveal>

          {/* CTA button — scrolls to final form */}
          <Reveal delay={240}>
            <a
              href="#final"
              className="group relative mt-4 inline-flex w-full max-w-md items-center justify-center gap-2 rounded-md bg-[var(--brand-neon)] px-6 py-3.5 text-[13px] font-semibold tracking-[0.12em] text-black transition-all hover:bg-[var(--brand-neon-soft)] hover:shadow-[0_0_50px_-10px_rgba(215,255,0,0.7)] md:text-sm lg:mt-8 lg:py-4"
            >
              QUERO DESCOBRIR MEU ARQUÉTIPO
              <span aria-hidden className="transition-transform group-hover:translate-x-1">→</span>
            </a>
          </Reveal>

          {/* Social proof */}
          <Reveal delay={340}>
            <div className="mt-4 flex items-center gap-3 lg:mt-7 lg:gap-4">
              <div className="flex flex-col">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-3 w-3 fill-current"
                      style={{ color: "var(--brand-neon)" }}
                    />
                  ))}
                </div>
                <p className="mt-0.5 text-[11px] leading-snug text-white/55 lg:text-[12px]">
                  <span className="text-white/85">Dezenas de marcas</span> impactadas
                  através de posicionamento estratégico.
                </p>
              </div>
            </div>
          </Reveal>

        </div>

        {/* Right: Cristiano (protagonist) + ebook accent
            Mobile: absolute layer covering top 68% of viewport so copy overlays bottom.
            Desktop: normal grid column. */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-0 flex h-[68%] items-start justify-center lg:pointer-events-auto lg:relative lg:order-2 lg:inset-auto lg:z-auto lg:h-auto lg:min-h-[860px] lg:items-end">
          {/* Backlight glow behind subject */}
          <div
            aria-hidden
            className="pointer-events-none absolute left-1/2 top-[38%] h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl lg:h-[640px] lg:w-[640px]"
            style={{
              background:
                "radial-gradient(closest-side, rgba(217,255,0,0.32), rgba(217,255,0,0.08) 55%, transparent 78%)",
            }}
          />
          {/* Warm rim light to brighten subject */}
          <div
            aria-hidden
            className="pointer-events-none absolute left-[60%] top-[28%] h-[360px] w-[360px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl lg:h-[520px] lg:w-[520px]"
            style={{
              background:
                "radial-gradient(closest-side, rgba(255,240,200,0.18), rgba(255,240,200,0.05) 50%, transparent 75%)",
            }}
          />
          {/* Cristiano photo - transparent PNG with bottom fade mask */}
          <img
            src={cristianoPhoto}
            alt="Cristiano Oliveira"
            className="pointer-events-none relative z-[1] h-full w-auto max-w-none object-contain object-top lg:h-[920px]"
            style={{
              filter:
                "brightness(1.09) contrast(1.05) saturate(1.06) drop-shadow(0 0 60px rgba(255,240,200,0.18)) drop-shadow(0 30px 50px rgba(0,0,0,0.55))",
              WebkitMaskImage:
                "linear-gradient(180deg, #000 0%, #000 45%, rgba(0,0,0,0.55) 70%, rgba(0,0,0,0.15) 88%, transparent 100%)",
              maskImage:
                "linear-gradient(180deg, #000 0%, #000 45%, rgba(0,0,0,0.55) 70%, rgba(0,0,0,0.15) 88%, transparent 100%)",
            }}
          />
          {/* Bottom blend into background */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-0 bottom-0 z-[2] h-56 lg:h-48"
            style={{
              background:
                "linear-gradient(180deg, transparent 0%, rgba(5,5,5,0.45) 40%, rgba(5,5,5,0.85) 75%, #050505 100%)",
            }}
          />

          {/* Static ebook accent
              Mobile: chest height (green line), small.
              Desktop: bottom-left. */}
          <div className="absolute left-5 top-[36%] z-[3] origin-top-left scale-[0.5] sm:left-7 sm:top-[34%] sm:scale-[0.6] lg:left-10 lg:top-auto lg:bottom-6 lg:origin-bottom-left lg:scale-100">
            <Reveal delay={220}>
              <div className="relative">
                {/* Floor contact shadow */}
                <div
                  aria-hidden
                  className="absolute left-1/2 -bottom-3 h-6 w-[80%] -translate-x-1/2 rounded-[50%] opacity-30 blur-xl lg:opacity-70"
                  style={{ background: "rgba(0,0,0,0.85)" }}
                />
                {/* Soft neon underglow */}
                <div
                  aria-hidden
                  className="absolute left-1/2 -bottom-6 h-8 w-[70%] -translate-x-1/2 rounded-[50%] opacity-25 blur-2xl lg:opacity-40"
                  style={{ background: "rgba(217,255,0,0.18)" }}
                />
                <EbookMockup size="md" />
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- PROBLEM ---------------- */
const problems = [
  { icon: Eye, title: "Parece genérica", desc: "Visual e discurso que se confundem com qualquer outra marca do segmento." },
  { icon: Target, title: "Dificuldade de diferenciação", desc: "O mercado não consegue dizer o que torna você único." },
  { icon: TrendingDown, title: "Guerra de preço", desc: "Sem percepção de valor, sobra apenas o desconto como argumento." },
  { icon: Crown, title: "Baixa percepção de valor", desc: "Sua entrega é premium, mas a marca não comunica isso." },
  { icon: MessageSquareOff, title: "Comunicação desalinhada", desc: "Cada canal fala uma língua diferente sobre você." },
  { icon: Fingerprint, title: "Falta de identidade forte", desc: "Sem assinatura simbólica, sua marca não se fixa na memória." },
];

function ProblemSection() {
  return (
    <Section className="border-t border-brand-line">
      <Reveal>
        <Eyebrow>O diagnóstico</Eyebrow>
      </Reveal>
      <Reveal delay={80}>
        <h2 className="display-font max-w-3xl text-3xl leading-[1.1] md:text-5xl">
          Sua marca pode estar comunicando a coisa errada
          <span style={{ color: "var(--brand-neon)" }}>
            {" "}— sem você perceber.
          </span>
        </h2>
      </Reveal>

      <div className="mt-12 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-brand-line bg-[rgba(255,255,255,0.04)] sm:grid-cols-2 lg:grid-cols-3">
        {problems.map((p, i) => (
          <Reveal
            key={p.title}
            delay={i * 60}
            className="group relative bg-[#070707] p-6 transition-colors hover:bg-[#0b0b0b] md:p-8"
          >
            <div className="mb-5 inline-flex h-10 w-10 items-center justify-center rounded-md border border-brand-line bg-white/[0.02]">
              <p.icon className="h-4.5 w-4.5" style={{ color: "var(--brand-neon)" }} />
            </div>
            <h3 className="display-font text-lg text-white">{p.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-brand-muted">{p.desc}</p>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- BENEFITS ---------------- */
const benefits = [
  { icon: Brain, title: "Como os arquétipos moldam percepção", desc: "Por que algumas marcas são instantaneamente reconhecidas e desejadas." },
  { icon: Heart, title: "O motivo de marcas serem memoráveis", desc: "Os padrões psicológicos que criam vínculo emocional duradouro." },
  { icon: Crown, title: "Como gerar autoridade e conexão", desc: "Posicionamento que transmite valor antes mesmo do primeiro contato." },
  { icon: Sparkles, title: "Os arquétipos das marcas fortes", desc: "Estruturas usadas pelas marcas mais valiosas e desejadas do mundo." },
  { icon: Search, title: "Padrões invisíveis da sua comunicação", desc: "Como identificar o que sua marca transmite — e o que está faltando." },
];

function BenefitsSection() {
  return (
    <Section className="border-t border-brand-line">
      <Reveal>
        <Eyebrow>O que você vai descobrir</Eyebrow>
      </Reveal>
      <Reveal delay={80}>
        <h2 className="display-font max-w-3xl text-3xl leading-[1.1] md:text-5xl">
          Cinco descobertas que mudam como você constrói a sua marca.
        </h2>
      </Reveal>

      <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {benefits.map((b, i) => (
          <Reveal
            key={b.title}
            delay={i * 70}
            className="group relative overflow-hidden rounded-xl border border-brand-line bg-gradient-to-b from-white/[0.02] to-transparent p-7 transition-all hover:border-[rgba(215,255,0,0.25)] hover:bg-white/[0.03]"
          >
            <div
              aria-hidden
              className="pointer-events-none absolute -inset-px rounded-xl opacity-0 transition-opacity group-hover:opacity-100"
              style={{ boxShadow: "inset 0 0 60px -10px rgba(215,255,0,0.1)" }}
            />
            <div className="mb-6 inline-flex h-11 w-11 items-center justify-center rounded-lg border border-brand-line bg-white/[0.03]">
              <b.icon className="h-5 w-5" style={{ color: "var(--brand-neon)" }} />
            </div>
            <h3 className="display-font text-lg text-white">{b.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-brand-muted">
              {b.desc}
            </p>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- MECHANISM ---------------- */
function MechanismSection() {
  return (
    <Section className="relative border-t border-brand-line">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(40% 60% at 50% 50%, rgba(215,255,0,0.06), transparent 70%)",
        }}
      />
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div>
          <Reveal>
            <Eyebrow>O mecanismo</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-font text-3xl leading-[1.1] md:text-5xl">
              Branding forte não nasce apenas do visual.
              <br />
              <span style={{ color: "var(--brand-neon)" }}>
                Nasce da percepção.
              </span>
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-brand-muted md:text-lg">
              Os arquétipos são estruturas psicológicas estudadas por Carl Jung
              que influenciam identidade, desejo, reconhecimento e conexão
              emocional.
            </p>
          </Reveal>
          <Reveal delay={220}>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-brand-muted md:text-lg">
              Marcas fortes usam isso estrategicamente para se tornarem mais
              <span className="text-white"> desejadas, memoráveis e valiosas</span>.
            </p>
          </Reveal>
        </div>

        {/* Abstract editorial illustration */}
        <Reveal delay={120} className="relative flex items-center justify-center">
          <div className="relative aspect-square w-full max-w-md">
            <div
              aria-hidden
              className="absolute inset-0 rounded-full"
              style={{
                background:
                  "radial-gradient(closest-side, rgba(215,255,0,0.18), transparent 70%)",
              }}
            />
            {(() => {
              const cx = 200;
              const cy = 200;
              const rLabel = 168;
              const rDot = 152;
              const archetypes = [
                "INOCENTE",
                "SÁBIO",
                "EXPLORADOR",
                "HERÓI",
                "REBELDE",
                "MAGO",
                "CARA COMUM",
                "AMANTE",
                "BOBO",
                "CUIDADOR",
                "CRIADOR",
                "SOBERANO",
              ];
              const chosen = 10; // CRIADOR (topo-esquerda)
              const n = archetypes.length;
              const angleFor = (i: number) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
              const pt = (i: number, r: number) => {
                const a = angleFor(i);
                return [cx + Math.cos(a) * r, cy + Math.sin(a) * r] as const;
              };
              // Arc path for the highlight wedge on the outer ring
              const arcSpan = (Math.PI * 2) / n; // one segment
              const aMid = angleFor(chosen);
              const aStart = aMid - arcSpan / 2;
              const aEnd = aMid + arcSpan / 2;
              const rArc = 178;
              const arcStart = [cx + Math.cos(aStart) * rArc, cy + Math.sin(aStart) * rArc];
              const arcEnd = [cx + Math.cos(aEnd) * rArc, cy + Math.sin(aEnd) * rArc];
              const arcPath = `M ${arcStart[0].toFixed(2)} ${arcStart[1].toFixed(2)} A ${rArc} ${rArc} 0 0 1 ${arcEnd[0].toFixed(2)} ${arcEnd[1].toFixed(2)}`;
              const [lx, ly] = pt(chosen, rDot - 8);
              return (
                <svg viewBox="0 0 400 400" className="relative h-full w-full">
                  <defs>
                    <radialGradient id="centerCore" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="rgba(215,255,0,0.35)" />
                      <stop offset="60%" stopColor="rgba(215,255,0,0.08)" />
                      <stop offset="100%" stopColor="rgba(215,255,0,0)" />
                    </radialGradient>
                    <radialGradient id="chosenHalo" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="rgba(215,255,0,0.85)" />
                      <stop offset="100%" stopColor="rgba(215,255,0,0)" />
                    </radialGradient>
                    <filter id="neonGlow" x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur stdDeviation="3.5" result="b" />
                      <feMerge>
                        <feMergeNode in="b" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>

                  {/* Outer ring */}
                  <circle cx={cx} cy={cy} r={rArc} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="0.6" />
                  {/* Inner ring */}
                  <circle cx={cx} cy={cy} r="78" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="0.5" />

                  {/* Focus arc on chosen segment */}
                  <path
                    d={arcPath}
                    fill="none"
                    stroke="#d7ff00"
                    strokeWidth="2"
                    strokeLinecap="round"
                    filter="url(#neonGlow)"
                  />

                  {/* Connection line: center -> chosen */}
                  <line
                    x1={cx}
                    y1={cy}
                    x2={lx}
                    y2={ly}
                    stroke="#d7ff00"
                    strokeWidth="1.2"
                    strokeDasharray="2 3"
                    opacity="0.75"
                  />

                  {/* Dots + labels */}
                  {archetypes.map((label, i) => {
                    const [dx, dy] = pt(i, rDot);
                    const [tx, ty] = pt(i, rLabel);
                    const isChosen = i === chosen;
                    return (
                      <g key={i}>
                        {isChosen && (
                          <circle cx={dx} cy={dy} r="9" fill="url(#chosenHalo)">
                            <animate attributeName="r" values="7;12;7" dur="2.4s" repeatCount="indefinite" />
                            <animate attributeName="opacity" values="0.7;1;0.7" dur="2.4s" repeatCount="indefinite" />
                          </circle>
                        )}
                        <circle
                          cx={dx}
                          cy={dy}
                          r={isChosen ? 3 : 1.6}
                          fill={isChosen ? "#d7ff00" : "rgba(255,255,255,0.22)"}
                        />
                        <text
                          x={tx}
                          y={ty}
                          textAnchor="middle"
                          dominantBaseline="middle"
                          fontSize={isChosen ? 10 : 8.5}
                          letterSpacing="2"
                          fontFamily="ui-sans-serif, system-ui, sans-serif"
                          fontWeight={isChosen ? 700 : 500}
                          fill={isChosen ? "#ffffff" : "rgba(255,255,255,0.28)"}
                          style={isChosen ? { filter: "drop-shadow(0 0 6px rgba(215,255,0,0.55))" } : undefined}
                        >
                          {label}
                        </text>
                      </g>
                    );
                  })}

                  {/* Center badge */}
                  <circle cx={cx} cy={cy} r="62" fill="url(#centerCore)">
                    <animate attributeName="opacity" values="0.7;1;0.7" dur="3.2s" repeatCount="indefinite" />
                  </circle>
                  <circle cx={cx} cy={cy} r="54" fill="rgba(5,5,5,0.55)" stroke="rgba(215,255,0,0.35)" strokeWidth="0.8" />
                  <text
                    x={cx}
                    y={cy - 14}
                    textAnchor="middle"
                    fontSize="8"
                    letterSpacing="3"
                    fontFamily="ui-sans-serif, system-ui, sans-serif"
                    fill="rgba(255,255,255,0.55)"
                  >
                    SEU ARQUÉTIPO
                  </text>
                  <text
                    x={cx}
                    y={cy + 8}
                    textAnchor="middle"
                    fontSize="20"
                    letterSpacing="2"
                    fontFamily="ui-sans-serif, system-ui, sans-serif"
                    fontWeight={700}
                    fill="#ffffff"
                    style={{ filter: "drop-shadow(0 0 8px rgba(215,255,0,0.55))" }}
                  >
                    CRIADOR
                  </text>
                  <text
                    x={cx}
                    y={cy + 26}
                    textAnchor="middle"
                    fontSize="7"
                    letterSpacing="2"
                    fontFamily="ui-sans-serif, system-ui, sans-serif"
                    fill="rgba(215,255,0,0.7)"
                  >
                    1 DE 12
                  </text>
                </svg>
              );
            })()}
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

/* ---------------- AUTHOR ---------------- */
function AuthorSection() {
  return (
    <Section className="border-t border-brand-line">
      <div className="grid items-center gap-12 lg:grid-cols-[0.85fr_1.15fr]">
        {/* Photo placeholder */}
        <Reveal>
          <div className="relative mx-auto w-full max-w-sm">
            <div
              aria-hidden
              className="absolute -inset-6 rounded-2xl blur-3xl"
              style={{
                background:
                  "radial-gradient(closest-side, rgba(215,255,0,0.18), transparent 70%)",
              }}
            />
            <div className="relative aspect-[4/5] overflow-hidden rounded-xl border border-brand-line bg-gradient-to-b from-[#0c0c0c] to-[#050505]">
              <img
                src={cristianoPhoto}
                alt="Cristiano Oliveira, especialista em branding e arquétipos"
                className="h-full w-full object-cover object-top"
                loading="lazy"
                decoding="async"
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, transparent 60%, rgba(0,0,0,0.6) 100%)",
                }}
              />
            </div>
          </div>
        </Reveal>

        <div>
          <Reveal>
            <Eyebrow>Sobre o autor</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-font text-3xl leading-[1.1] md:text-5xl">
              Cristiano Oliveira
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <div className="mt-6 space-y-4 text-base leading-relaxed text-brand-muted md:text-[1.05rem]">
              <p>
                Especialista em branding, posicionamento e construção de marcas
                há mais de 20 anos. Com grandes cases no Brasil e no exterior,
                seu trabalho une estratégia, identidade e percepção para
                transformar marcas comuns em marcas memoráveis.
              </p>
              <p>
                Ao longo da sua trajetória, aprofundou-se no estudo dos
                arquétipos aplicados ao branding, utilizando psicologia,
                posicionamento e construção simbólica para desenvolver marcas
                com mais autoridade, diferenciação e valor percebido.
              </p>
              <p className="text-white">
                Seu método conecta identidade e percepção para criar marcas que
                não apenas vendem — mas permanecem.
              </p>
            </div>
          </Reveal>

          <Reveal delay={220}>
            <div className="mt-8 flex flex-wrap gap-3">
              {[
                { icon: Award, label: "+20 anos de experiência" },
                { icon: Sparkles, label: "Branding & Arquétipos" },
                { icon: Globe2, label: "Brasil & Exterior" },
              ].map((b) => (
                <span
                  key={b.label}
                  className="inline-flex items-center gap-2 rounded-full border border-brand-line bg-white/[0.03] px-4 py-2 text-xs text-white"
                >
                  <b.icon className="h-3.5 w-3.5" style={{ color: "var(--brand-neon)" }} />
                  {b.label}
                </span>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}

/* ---------------- PATTERN BREAK ---------------- */
function PatternBreakSection() {
  return (
    <section className="relative border-t border-brand-line bg-[#030303] px-5 py-28 md:px-8 md:py-40">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(50% 50% at 50% 50%, rgba(215,255,0,0.05), transparent 70%)",
        }}
      />
      <div className="relative mx-auto max-w-4xl text-center">
        <Reveal>
          <p className="display-font text-3xl leading-[1.15] text-white sm:text-4xl md:text-6xl">
            Existe uma diferença entre a marca que você criou
            <br />
            <span style={{ color: "var(--brand-neon)" }}>
              e a marca que o mercado percebe.
            </span>
          </p>
        </Reveal>
        <Reveal delay={140}>
          <p className="mx-auto mt-8 max-w-2xl text-base text-brand-muted md:text-lg">
            Entender essa diferença pode mudar completamente seu posicionamento,
            sua autoridade e o valor percebido da sua marca.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------- FINAL CTA ---------------- */
function FinalCTASection() {
  return (
    <Section id="final" className="scroll-mt-20 border-t border-brand-line">
      <div className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]">
        <Reveal className="flex justify-center lg:justify-start">
          <EbookMockup size="md" />
        </Reveal>
        <div>
          <Reveal>
            <Eyebrow>Acesso gratuito</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="display-font text-3xl leading-[1.1] md:text-5xl">
              Baixe o e-book e descubra qual identidade sua marca{" "}
              <span style={{ color: "var(--brand-neon)" }}>
                transmite ao mercado.
              </span>
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <div
              id="formulario-final"
              className="mt-8 max-w-md rounded-xl border border-brand-line bg-white/[0.02] p-5 backdrop-blur-sm md:p-6"
            >
              <LeadForm
                origem="final"
                ctaLabel="QUERO ACESSAR O E-BOOK AGORA"
              />
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}

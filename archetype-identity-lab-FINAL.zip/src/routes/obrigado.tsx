import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, MessageCircle, ArrowRight } from "lucide-react";
import { Footer } from "@/components/landing/Footer";
import { company } from "@/config/company";

export const Route = createFileRoute("/obrigado")({
  head: () => ({
    meta: [
      { title: "Cadastro confirmado | Cristiano Oliveira" },
      {
        name: "description",
        content:
          "Seu e-book será enviado pelo WhatsApp em instantes. Conheça a próxima etapa.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ObrigadoPage,
});

function ObrigadoPage() {
  return (
    <main className="flex min-h-screen flex-col bg-brand text-white">
      <section className="relative flex flex-1 items-center justify-center overflow-hidden px-5 py-20 md:px-8 md:py-28">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(50% 50% at 50% 30%, rgba(215,255,0,0.08), transparent 70%)",
          }}
        />
        <div className="mx-auto w-full max-w-2xl text-center">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-full border border-brand-line bg-white/[0.03]">
            <CheckCircle2
              className="h-7 w-7"
              style={{ color: "var(--brand-neon)" }}
            />
          </div>

          <div className="mt-6 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-brand-muted">
            <span className="h-px w-8 bg-[var(--brand-neon)]" />
            Cadastro confirmado
          </div>

          <h1 className="display-font mt-6 text-3xl leading-[1.1] md:text-5xl">
            Tudo certo. Seu e-book está a caminho{" "}
            <span style={{ color: "var(--brand-neon)" }}>pelo WhatsApp.</span>
          </h1>

          <p className="mx-auto mt-6 max-w-lg text-base leading-relaxed text-brand-muted md:text-lg">
            Em instantes você receberá o material diretamente no seu WhatsApp.
            Confira também sua caixa de mensagens e libere o número do
            Cristiano nos seus contatos.
          </p>

          <div className="mt-10 rounded-xl border border-brand-line bg-white/[0.02] p-6 text-left md:p-8">
            <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.28em] text-brand-muted">
              <MessageCircle
                className="h-3.5 w-3.5"
                style={{ color: "var(--brand-neon)" }}
              />
              Próxima etapa
            </div>
            <h2 className="display-font mt-3 text-xl leading-snug text-white md:text-2xl">
              Quer aplicar o arquétipo certo para a sua marca em uma sessão
              estratégica com Cristiano Oliveira?
            </h2>
            <p className="mt-3 text-sm text-brand-muted md:text-base">
              Vagas limitadas por mês. A próxima conversa pode redefinir o
              posicionamento da sua marca.
            </p>

            <a
              href={company.calendly}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-6 inline-flex items-center justify-center gap-2 rounded-md bg-[var(--brand-neon)] px-6 py-3.5 text-sm font-semibold tracking-[0.12em] text-black transition-all hover:bg-[var(--brand-neon-soft)] hover:shadow-[0_0_50px_-10px_rgba(215,255,0,0.7)]"
            >
              QUERO CONVERSAR COM CRISTIANO
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </a>
          </div>

          <div className="mt-10">
            <Link
              to="/"
              className="text-xs text-brand-muted underline-offset-4 hover:text-white hover:underline"
            >
              Voltar para a página inicial
            </Link>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
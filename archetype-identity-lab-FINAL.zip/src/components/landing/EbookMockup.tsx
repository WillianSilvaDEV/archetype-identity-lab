import ebookCover from "@/assets/ebook-cover.webp";

type Props = { className?: string; size?: "lg" | "md" };

export function EbookMockup({ className = "", size = "lg" }: Props) {
  const w = size === "lg" ? 320 : 240;
  const h = size === "lg" ? 427 : 320;
  return (
    <div className={`relative ${className}`} style={{ width: w, height: h }}>
      {/* Soft neon glow halo - kept tight to avoid covering nearby content */}
      <div
        aria-hidden
        className="absolute -inset-4 rounded-2xl blur-2xl opacity-40"
        style={{
          background:
            "radial-gradient(closest-side, rgba(215,255,0,0.22), rgba(215,255,0,0.05) 55%, transparent 70%)",
        }}
      />
      {/* Book wrapper with 3D tilt */}
      <div
        className="relative h-full w-full"
        style={{
          transform: "perspective(1400px) rotateY(-22deg) rotateX(6deg)",
          transformStyle: "preserve-3d",
        }}
      >
        {/* Spine shadow */}
        <div
          aria-hidden
          className="absolute left-0 top-0 h-full w-3 rounded-l-md"
          style={{
            background:
              "linear-gradient(to right, rgba(0,0,0,0.85), rgba(0,0,0,0))",
            transform: "translateZ(-1px)",
          }}
        />
        {/* Cover */}
        <div
          className="relative h-full w-full overflow-hidden rounded-md"
          style={{
            boxShadow:
              "0 40px 80px -30px rgba(0,0,0,0.9), inset 0 0 0 1px rgba(255,255,255,0.06)",
          }}
        >
          <img
            src={ebookCover}
            alt="Capa do e-book Descubra o Seu Arquetipo de Marca"
            className="h-full w-full object-cover"
            loading="eager"
            decoding="async"
          />
          {/* gloss */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "linear-gradient(115deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 30%, rgba(255,255,255,0) 70%, rgba(255,255,255,0.04) 100%)",
            }}
          />
        </div>
      </div>
    </div>
  );
}
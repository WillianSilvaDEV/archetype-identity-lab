import { useEffect, useState } from "react";

export function StickyCTA() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 700);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToForm = () => {
    const el =
      document.getElementById("formulario-final") ||
      document.getElementById("formulario-hero");
    el?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 border-t border-brand-line bg-[#050505]/90 px-4 py-3 backdrop-blur-md transition-all md:hidden ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-full opacity-0"
      }`}
      style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
    >
      <button
        onClick={scrollToForm}
        className="w-full rounded-md bg-[var(--brand-neon)] px-5 py-3.5 text-xs font-semibold tracking-[0.14em] text-black"
      >
        QUERO MEU ARQUÉTIPO
      </button>
    </div>
  );
}
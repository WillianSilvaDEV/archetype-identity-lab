import type { ReactNode } from "react";

export function Section({
  id,
  children,
  className = "",
}: {
  id?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      id={id}
      className={`relative w-full px-5 py-20 md:px-8 md:py-28 lg:py-32 ${className}`}
    >
      <div className="mx-auto w-full max-w-6xl">{children}</div>
    </section>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <div className="mb-5 inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.32em] text-brand-muted">
      <span className="h-px w-8 bg-[var(--brand-neon)]" />
      {children}
    </div>
  );
}
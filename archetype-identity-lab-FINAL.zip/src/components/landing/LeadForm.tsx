import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { toast } from "sonner";
import { submitLead } from "@/lib/leads.functions";

const schema = z.object({
  nome: z.string().trim().min(2, "Informe seu nome").max(100),
  whatsapp: z
    .string()
    .trim()
    .min(8, "WhatsApp invalido")
    .max(25)
    .regex(/^[0-9+\s()\-]+$/, "Use apenas numeros"),
  email: z.string().trim().email("E-mail invalido").max(255),
  colaboradores: z.enum(
    ["ate_5", "5_10", "10_20", "20_50", "50_100", "acima_100"],
    { message: "Selecione o tamanho da empresa" },
  ),
  optin_whatsapp: z.literal(true, {
    errorMap: () => ({ message: "É necessário autorizar para continuar" }),
  }),
});

function maskWhatsapp(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 2) return d;
  if (d.length <= 7) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

type Props = { origem: string; ctaLabel?: string; compact?: boolean };

export function LeadForm({ origem, ctaLabel = "QUERO DESCOBRIR MEU ARQUETIPO", compact = false }: Props) {
  const submit = useServerFn(submitLead);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [values, setValues] = useState<{
    nome: string;
    whatsapp: string;
    email: string;
    colaboradores: string;
    optin_whatsapp: boolean;
  }>({
    nome: "",
    whatsapp: "",
    email: "",
    colaboradores: "",
    optin_whatsapp: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const onChange =
    (k: "nome" | "whatsapp" | "email" | "colaboradores") =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const raw = e.target.value;
      const v = k === "whatsapp" ? maskWhatsapp(raw) : raw;
      setValues((s) => ({ ...s, [k]: v }));
      if (errors[k]) setErrors((s) => ({ ...s, [k]: "" }));
    };

  const onOptinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValues((s) => ({ ...s, optin_whatsapp: e.target.checked }));
    if (errors.optin_whatsapp)
      setErrors((s) => ({ ...s, optin_whatsapp: "" }));
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[i.path[0] as string] = i.message;
      setErrors(errs);
      return;
    }
    setLoading(true);
    try {
      const res = await submit({
        data: {
          nome: parsed.data.nome,
          whatsapp: parsed.data.whatsapp,
          email: parsed.data.email,
          colaboradores: parsed.data.colaboradores,
          optin_whatsapp: parsed.data.optin_whatsapp,
          origem,
          user_agent: typeof navigator !== "undefined" ? navigator.userAgent : undefined,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      navigate({ to: "/obrigado" });
    } catch (err) {
      console.error(err);
      toast.error("Erro inesperado. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const inputBase =
    "w-full rounded-md border border-brand-line bg-white/[0.03] px-4 py-3.5 text-base text-white placeholder:text-white/30 outline-none transition-all focus:border-[var(--brand-neon)] focus:bg-white/[0.05] focus:ring-2 focus:ring-[var(--brand-neon)]/20";

  return (
    <form onSubmit={onSubmit} className={`w-full space-y-3 ${compact ? "" : ""}`} noValidate>
      <div>
        <input
          type="text"
          inputMode="text"
          autoComplete="name"
          placeholder="Seu nome"
          value={values.nome}
          onChange={onChange("nome")}
          className={inputBase}
          aria-invalid={!!errors.nome}
        />
        {errors.nome && <p className="mt-1 text-xs text-red-400">{errors.nome}</p>}
      </div>
      <div>
        <input
          type="tel"
          inputMode="tel"
          autoComplete="tel"
          placeholder="WhatsApp com DDD"
          value={values.whatsapp}
          onChange={onChange("whatsapp")}
          className={inputBase}
          aria-invalid={!!errors.whatsapp}
        />
        {errors.whatsapp && <p className="mt-1 text-xs text-red-400">{errors.whatsapp}</p>}
      </div>
      <div>
        <input
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="Seu melhor e-mail"
          value={values.email}
          onChange={onChange("email")}
          className={inputBase}
          aria-invalid={!!errors.email}
        />
        {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
      </div>
      <div>
        <select
          value={values.colaboradores}
          onChange={onChange("colaboradores")}
          className={`${inputBase} appearance-none bg-[length:14px] bg-[right_1rem_center] bg-no-repeat pr-10 ${values.colaboradores ? "" : "text-white/40"}`}
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='2'><path d='M6 9l6 6 6-6'/></svg>\")",
          }}
          aria-invalid={!!errors.colaboradores}
        >
          <option value="" disabled className="bg-black text-white/60">
            Quantos colaboradores na empresa?
          </option>
          <option value="ate_5" className="bg-black text-white">Ate 5</option>
          <option value="5_10" className="bg-black text-white">Entre 5 e 10</option>
          <option value="10_20" className="bg-black text-white">Entre 10 e 20</option>
          <option value="20_50" className="bg-black text-white">Entre 20 e 50</option>
          <option value="50_100" className="bg-black text-white">Entre 50 e 100</option>
          <option value="acima_100" className="bg-black text-white">Acima de 100</option>
        </select>
        {errors.colaboradores && (
          <p className="mt-1 text-xs text-red-400">{errors.colaboradores}</p>
        )}
      </div>

      <p className="pt-1 text-center text-[11px] text-brand-muted">
        Acesso gratuito — Leitura imediata — Sem spam
      </p>

      <div className="pt-1">
        <label className="flex cursor-pointer items-start gap-3 text-left">
          <input
            type="checkbox"
            checked={values.optin_whatsapp}
            onChange={onOptinChange}
            className="mt-0.5 h-4 w-4 shrink-0 rounded border border-brand-line bg-white/[0.03] accent-[var(--brand-neon)]"
            aria-invalid={!!errors.optin_whatsapp}
          />
          <span className="text-[11.5px] leading-snug text-brand-muted">
            Autorizo o envio do e-book e de comunicações de Cristiano Oliveira
            pelo meu WhatsApp e e-mail. Li e concordo com a{" "}
            <Link
              to="/politica-de-privacidade"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-2"
              style={{ color: "var(--brand-neon)" }}
            >
              Política de Privacidade
            </Link>{" "}
            e os{" "}
            <Link
              to="/termos-de-uso"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-2"
              style={{ color: "var(--brand-neon)" }}
            >
              Termos de Uso
            </Link>
            .
          </span>
        </label>
        {errors.optin_whatsapp && (
          <p className="mt-1 text-xs text-red-400">{errors.optin_whatsapp}</p>
        )}
      </div>

      <button
        type="submit"
        disabled={loading}
        className="group relative mt-2 flex w-full items-center justify-center gap-2 rounded-md bg-[var(--brand-neon)] px-6 py-4 text-sm font-semibold tracking-[0.12em] text-black transition-all hover:bg-[var(--brand-neon-soft)] hover:shadow-[0_0_50px_-10px_rgba(215,255,0,0.7)] disabled:opacity-60"
      >
        {loading ? "ENVIANDO..." : ctaLabel}
      </button>
    </form>
  );
}
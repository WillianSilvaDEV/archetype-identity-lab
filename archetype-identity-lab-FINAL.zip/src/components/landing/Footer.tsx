import { Link } from "@tanstack/react-router";
import { company } from "@/config/company";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-brand-line px-5 py-12 md:px-8 md:py-14">
      <div className="mx-auto grid w-full max-w-6xl gap-10 md:grid-cols-3">
        {/* Coluna 1 — Empresa */}
        <div>
          <div className="display-font text-sm text-white">
            Cristiano Oliveira
            <span style={{ color: "var(--brand-neon)" }}>.</span>
          </div>
          <p className="mt-2 text-xs text-brand-muted">
            Branding estratégico — Arquétipos aplicados
          </p>
          <div className="mt-4 space-y-1 text-[11px] leading-relaxed text-brand-muted">
            <p>{company.razaoSocial}</p>
            <p>CNPJ: {company.cnpj}</p>
            <p>{company.endereco}</p>
          </div>
        </div>

        {/* Coluna 2 — Contato */}
        <div>
          <h3 className="text-[11px] uppercase tracking-[0.28em] text-white/70">
            Contato
          </h3>
          <ul className="mt-4 space-y-2 text-xs text-brand-muted">
            <li>
              <a
                href={`mailto:${company.emailContato.replace(/[\[\]]/g, "")}`}
                className="hover:text-white"
              >
                {company.emailContato}
              </a>
            </li>
            <li>
              <a
                href={company.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white"
              >
                WhatsApp: {company.whatsappDisplay}
              </a>
            </li>
            <li>{company.horarioAtendimento}</li>
          </ul>
        </div>

        {/* Coluna 3 — Links legais */}
        <div>
          <h3 className="text-[11px] uppercase tracking-[0.28em] text-white/70">
            Informações legais
          </h3>
          <ul className="mt-4 space-y-2 text-xs text-brand-muted">
            <li>
              <Link to="/politica-de-privacidade" className="hover:text-white">
                Política de Privacidade
              </Link>
            </li>
            <li>
              <Link to="/termos-de-uso" className="hover:text-white">
                Termos de Uso
              </Link>
            </li>
            <li>
              <a href="#top" className="hover:text-white">
                Voltar ao topo
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="mx-auto mt-10 flex max-w-6xl border-t border-brand-line pt-6 text-[11px] text-brand-muted">
        <p>
          © {year} {company.razaoSocial} — Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export type LeadInput = {
  nome: string;
  whatsapp: string;
  email: string;
  colaboradores: "ate_5" | "5_10" | "10_20" | "20_50" | "50_100" | "acima_100";
  optin_whatsapp: true;
  origem?: string;
  user_agent?: string;
};

export async function insertLead(data: LeadInput) {
  const { error } = await supabaseAdmin.from("leads").insert({
    nome: data.nome,
    whatsapp: data.whatsapp,
    email: data.email.toLowerCase(),
    colaboradores: data.colaboradores,
    optin_whatsapp: data.optin_whatsapp,
    optin_at: new Date().toISOString(),
    origem: data.origem ?? null,
    user_agent: data.user_agent ?? null,
  });
  return { error };
}

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const colaboradoresEnum = z.enum([
  "ate_5",
  "5_10",
  "10_20",
  "20_50",
  "50_100",
  "acima_100",
]);

const leadSchema = z.object({
  nome: z.string().trim().min(2, "Nome muito curto").max(100),
  whatsapp: z
    .string()
    .trim()
    .min(8, "WhatsApp invalido")
    .max(25)
    .regex(/^[0-9+\s()\-]+$/, "WhatsApp invalido"),
  email: z.string().trim().email("E-mail invalido").max(255),
  colaboradores: colaboradoresEnum,
  optin_whatsapp: z.literal(true, {
    errorMap: () => ({ message: "Autorização de contato obrigatória" }),
  }),
  origem: z.string().trim().max(80).optional(),
  user_agent: z.string().trim().max(500).optional(),
});

export const submitLead = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => leadSchema.parse(input))
  .handler(async ({ data }) => {
    const { insertLead } = await import("@/server/leads.server");
    const { error } = await insertLead(data);
    if (error) {
      console.error("[leads] insert error", error);
      return { ok: false as const, error: "Nao foi possivel registrar agora. Tente novamente." };
    }
    return { ok: true as const };
  });

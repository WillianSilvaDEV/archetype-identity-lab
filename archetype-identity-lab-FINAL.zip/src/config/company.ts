// Dados institucionais — preencher os campos entre colchetes.
// Centralizados aqui para que Footer, páginas legais, sitemap e metatags consumam tudo de um único lugar.

export const company = {
  razaoSocial: "[RAZÃO SOCIAL LTDA]",
  nomeFantasia: "Cristiano Oliveira",
  cnpj: "[00.000.000/0001-00]",
  endereco: "[Rua Exemplo, 123, Bairro, Cidade/UF, CEP 00000-000]",
  emailContato: "[contato@cristianooliveira.com.br]",
  emailDpo: "[dpo@cristianooliveira.com.br]",
  whatsappDisplay: "[+55 (11) 90000-0000]",
  whatsappLink: "https://wa.me/5511900000000",
  calendly: "https://calendly.com/cristianooliveira/sessao",
  horarioAtendimento: "Seg a Sex, 9h às 18h",
  dominio: "cristianooliveira.com.br",
  siteUrl: "https://cristianooliveira.com.br",
  versaoLegal: "1.0",
  dataAtualizacaoLegal: "16/05/2026",
} as const;

export type Company = typeof company;
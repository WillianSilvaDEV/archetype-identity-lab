alter table public.leads add column colaboradores text;

drop policy "anyone can insert leads" on public.leads;

create policy "anyone can insert leads"
on public.leads
for insert
to anon, authenticated
with check (
  char_length(nome) between 2 and 100
  and char_length(whatsapp) between 8 and 25
  and char_length(email) between 5 and 255
  and colaboradores in ('ate_5','5_10','10_20','20_50','50_100','acima_100')
);
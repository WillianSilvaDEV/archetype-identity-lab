create table public.leads (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  whatsapp text not null,
  email text not null,
  origem text,
  user_agent text,
  created_at timestamptz not null default now()
);

alter table public.leads enable row level security;

create policy "anyone can insert leads"
on public.leads
for insert
to anon, authenticated
with check (
  char_length(nome) between 2 and 100
  and char_length(whatsapp) between 8 and 25
  and char_length(email) between 5 and 255
);

create index leads_created_at_idx on public.leads (created_at desc);
create index leads_email_idx on public.leads (email);
-- Persistir o opt-in explícito do usuário para fins de auditoria LGPD.
-- Leads anteriores ficam com optin_whatsapp = false (não temos como provar consentimento retroativo).

alter table public.leads
  add column optin_whatsapp boolean not null default false,
  add column optin_at timestamptz;

drop policy "anyone can insert leads" on public.leads;

create policy "anyone can insert leads"
on public.leads
for insert
to anon, authenticated
with check (
  char_length(nome) between 2 and 100
  and char_length(whatsapp) between 8 and 25
  and char_length(email) between 5 and 255
  and colaboradores in ('ate_5','5_10','10_20','20_50','50_100','acima_100')
  and optin_whatsapp = true
  and optin_at is not null
);

create index leads_optin_at_idx on public.leads (optin_at desc) where optin_whatsapp = true;

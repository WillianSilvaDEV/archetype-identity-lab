# Archetype Identity Lab

Landing page de captura de leads para o e-book *Arquétipos de Marca* — Cristiano Oliveira.

**Stack:** TanStack Start (React 19 SSR) + Tailwind v4 + shadcn/ui + Supabase, deployado em **Cloudflare Workers**.

## Pré-requisitos

- Node 20+ ou Bun 1.1+
- Conta no Supabase com o projeto criado
- Conta na Cloudflare para deploy

## Setup local

```bash
# 1. Instalar dependências
bun install
# (ou npm install)

# 2. Copiar .env.example para .env e preencher com as chaves do Supabase
cp .env.example .env

# 3. Criar arquivo .dev.vars na raiz com a service role key
echo 'SUPABASE_SERVICE_ROLE_KEY="sua-service-role-key-aqui"' > .dev.vars

# 4. PREENCHER src/config/company.ts com os dados reais (razão social, CNPJ, endereço, etc.)

# 5. Rodar
bun run dev
```

Abre em http://localhost:8080.

## Migrations do Supabase

```bash
# Linkar ao projeto remoto (1ª vez)
supabase link --project-ref SEU_PROJETO_ID

# Aplicar migrations
supabase db push
```

Se preferir, abra cada arquivo de `supabase/migrations/` e cole o SQL diretamente no SQL Editor do painel Supabase.

Após aplicar a migration `20260516233700_optin_audit_trail.sql`, opcionalmente regenere os tipos:

```bash
supabase gen types typescript --linked > src/integrations/supabase/types.ts
```

> Os tipos já estão atualizados no repo — não precisa regenerar antes do primeiro build.

## Deploy em produção (Cloudflare Workers)

### Opção 1 — Via Git integration (recomendado, sem terminal)

1. No painel Cloudflare → **Workers & Pages** → **Create application** → **Import a repository**
2. Conecta o GitHub e seleciona este repo
3. Configura build command como `bun install && bun run build`
4. Adiciona as variáveis de ambiente (ver tabela abaixo)
5. **Save and Deploy**

A partir daí, cada push na branch `main` re-deploya automaticamente.

### Opção 2 — Via terminal

```bash
# Login (1ª vez)
bunx wrangler login

# Configurar secrets (1ª vez)
bunx wrangler secret put SUPABASE_URL
bunx wrangler secret put SUPABASE_PUBLISHABLE_KEY
bunx wrangler secret put SUPABASE_SERVICE_ROLE_KEY

# Deploy
bun run deploy
```

## Variáveis de ambiente

| Variável | Local (.env) | Local server (.dev.vars) | Cloudflare |
|---|---|---|---|
| `SUPABASE_URL` | ✅ | ✅ | Plaintext |
| `SUPABASE_PUBLISHABLE_KEY` | ✅ | ✅ | Plaintext |
| `VITE_SUPABASE_URL` | ✅ | — | Plaintext |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | ✅ | — | Plaintext |
| `VITE_SUPABASE_PROJECT_ID` | ✅ | — | Plaintext |
| `SUPABASE_SERVICE_ROLE_KEY` | ❌ NUNCA | ✅ | **Secret** ⚠️ |

A **service role key** nunca pode ir para o bundle do cliente nem para variáveis Plaintext da Cloudflare. Use sempre como Secret.

## Estrutura

```
src/
├── components/landing/   # Hero, Footer, LeadForm, EbookMockup, StickyCTA, Reveal, Section
├── components/ui/        # shadcn/ui (Radix + cva)
├── config/company.ts     # Dados institucionais (preencher antes de subir!)
├── integrations/supabase # Clients anon + admin, types, middlewares
├── lib/leads.functions.ts# Server fn que recebe lead (com opt-in obrigatório)
├── server/leads.server.ts# Insert no Supabase
├── server.ts             # Entry SSR (com wrapper de erro)
├── routes/
│   ├── __root.tsx                 # Shell + 404 + Error em PT-BR
│   ├── index.tsx                  # Landing
│   ├── obrigado.tsx               # Thank-you (noindex)
│   ├── politica-de-privacidade.tsx
│   └── termos-de-uso.tsx
└── styles.css            # Design tokens OKLCH + utilitários de marca
```

## Conformidade Meta / LGPD

Este site foi preparado para captura de leads via WhatsApp e atende aos requisitos para verificação Meta Business / WhatsApp Cloud API:

- Política de Privacidade (`/politica-de-privacidade`) com 12 seções LGPD
- Termos de Uso (`/termos-de-uso`)
- Footer com razão social, CNPJ, endereço e canais de contato
- Checkbox de opt-in **obrigatória, não pré-marcada**, com link para as duas páginas legais
- Consentimento **persistido no banco** (`optin_whatsapp` + `optin_at`) para trilha de auditoria
- RLS exigindo `optin_whatsapp = true` no insert
- HTML `lang="pt-BR"`, metatags PT-BR, OG image 1200×630
- `noindex` em `/obrigado`

### O que falta fora do código (manual)

1. Verificar a empresa no Meta Business Manager (CNPJ + documentos)
2. Cadastrar o número dedicado na WhatsApp Cloud API
3. Submeter templates de mensagem (categoria "utility" para entrega do e-book)
4. Implementar a integração de envio do e-book via Cloud API após o insert do lead

## Scripts

```bash
bun run dev         # dev server (http://localhost:8080)
bun run build       # build de produção
bun run preview     # preview local da build
bun run deploy      # build + wrangler deploy
bun run cf-typegen  # gera tipos das bindings Cloudflare
bun run lint        # ESLint
bun run format      # Prettier
```

## Licença

Propriedade de Cristiano Oliveira. Todos os direitos reservados.

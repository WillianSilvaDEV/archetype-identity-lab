import { defineConfig, loadEnv } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";
import { cloudflare } from "@cloudflare/vite-plugin";

export default defineConfig(({ mode }) => {
  // Expor variáveis VITE_* do .env como import.meta.env.* (parity com o wrapper anterior).
  const env = loadEnv(mode, process.cwd(), "");
  const define: Record<string, string> = {};
  for (const [k, v] of Object.entries(env)) {
    if (k.startsWith("VITE_")) {
      define[`import.meta.env.${k}`] = JSON.stringify(v);
    }
  }

  return {
    plugins: [
      tsConfigPaths(),
      tailwindcss(),
      tanstackStart({
        server: { entry: "server" },
      }),
      viteReact(),
      cloudflare({ viteEnvironment: { name: "ssr" } }),
    ],
    define,
    resolve: {
      dedupe: [
        "react",
        "react-dom",
        "@tanstack/react-router",
        "@tanstack/react-query",
      ],
    },
    server: {
      port: 8080,
      host: true,
      strictPort: false,
    },
  };
});
